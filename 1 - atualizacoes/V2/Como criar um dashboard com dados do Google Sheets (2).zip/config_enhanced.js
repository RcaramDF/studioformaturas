// Arquivo de configuração para o Dashboard Financeiro

// Configurações de API para acesso aos dados
const CONFIG = {
    // URL da API SheetDB (substitua pela sua URL após criar a conexão)
    apiUrl: 'https://sheetdb.io/api/v1/sua_api_id_aqui',
    
    // Configurações de atualização
    refreshInterval: 3600000, // Intervalo de atualização em ms (1 hora)
    
    // Configurações de visualização
    defaultDateRange: {
        start: null, // Data inicial padrão (null = sem filtro)
        end: null    // Data final padrão (null = sem filtro)
    },
    
    // Mapeamento de colunas da planilha para o dashboard
    columnMapping: {
        descricao: 'Descrição',
        valorPagamento: 'Valor Pagamento',
        categoria: 'Categoria',
        fornecedor: 'Fornecedor',
        servico: 'Serviço',
        vencimento: 'Vencimento',
        dataPagamento: 'Data Pagamento',
        statusPagamento: 'status do pagamento',
        mesVencimento: 'Mes de Vencimento'
    },
    
    // Configurações visuais
    colors: {
        primary: '#1a3a5f',    // Azul escuro
        secondary: '#f7a928',  // Laranja/amarelo
        success: '#2ecc71',    // Verde
        warning: '#f39c12',    // Amarelo
        danger: '#e74c3c',     // Vermelho
        light: '#e6eaef',      // Cinza claro
        dark: '#2c3e50'        // Cinza escuro
    }
};

// Exportar configurações para uso no dashboard
if (typeof module !== 'undefined') {
    module.exports = CONFIG;
}
